## 0.3.0 (2019-02-09)

* Require acorn >= 6.1.0

## 0.2.3 (2019-02-09)

* Forbid binding await in async arrow function's parameter list

## 0.2.2 (2019-01-30)

* Fix parsing of chained subscripts

## 0.2.1 (2018-11-06)

* Adapt to changes in acorn 6.0.3

## 0.2.0 (2018-09-14)

* Update to new acorn 6 interface
* Change license to MIT
* Don't allow direct super() calls in private methods

## 0.1.1 (2018-02-09)

* Don't accept whitespace between hash and private name

## 0.1.0 (2018-01-13)

Initial release
